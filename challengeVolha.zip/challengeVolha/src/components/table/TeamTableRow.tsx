import React, { useState } from "react";
import Modal from "../modal/Modal";
import { Team } from "../../types";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import imageDefault from "../../assets/images/default.png";
import styles from "./Table.module.css";

interface TeamTableHeaderProps {
  team: Team;
}

const TeamTableRow: React.FC<TeamTableHeaderProps> = ({ team }) => {
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const stateClass = `state-${team.state}`;
console.log(team.logo);

  const openModal = () => {
    if (team.state === "recorded" || team.state === "recording") {
      setModalIsOpen(true);
    }
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  return (
    <>
      <tr>
        <td>
          {team?.logo && "data" in team.logo ? (
            <img src={team.logo.data} alt={team.name} width="40" />
          ) : (
            <img src={imageDefault} alt={team.name} width="40" />
          )}
        </td>
        <td>{team.name}</td>
        <td>{team.field}</td>
        <td>{team.community}</td>
        <td>{team.nextSchedule ? team.nextSchedule : "N/A"}</td>
        <td>
          {team.state ? (
            <div className={`${styles[stateClass]}`}>
              {team.state.toUpperCase()}
            </div>
          ) : (
            <div className={styles.nodata}>N/A</div>
          )}
        </td>
        <td>
          {team.isRecorded ? (
            <FontAwesomeIcon
              icon={faEye}
              size="sm"
              style={{ color: "#36bf4d" }}
              onClick={openModal}
            />
          ) : (
            <FontAwesomeIcon
              icon={faEyeSlash}
              size="sm"
              style={{ color: "#f44366" }}
            />
          )}
        </td>
      </tr>
      <div>
        {team.state === "recorded" ||
          (team.state === "recording" && (
            <Modal modalIsOpen={modalIsOpen} onRequestClose={closeModal}>
              {team.name}
            </Modal>
          ))}
      </div>
    </>
  );
};

export default TeamTableRow;
