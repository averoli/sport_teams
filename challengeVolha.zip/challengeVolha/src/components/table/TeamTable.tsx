import React from "react";
import TeamTableHeader from "./TeamTableHeader";
import TeamTableRow from "./TeamTableRow";
import { Team } from "../../types";
import styles from "./Table.module.css";

type Props = {
  teams: Team[];
};

const TeamTable: React.FC<Props> = ({ teams }) => {
 
  return (
    <table className={styles.table}>
      <thead>
        <TeamTableHeader />
      </thead>

      <tbody>
        {teams.map((team, index) => (
          <TeamTableRow key={index} team={team} />
        ))}
      </tbody>
    </table>
  );
};

export default TeamTable;
