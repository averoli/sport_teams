import React  from "react";



const TeamTableHeader = () => {

  return (
    <tr>
      <th>Logo</th>
      <th>Name</th>
      <th>Field</th>
      <th>
        Community
        <button>
          <span>&uarr;</span>
        </button>
      </th>
      <th>Next Session</th>
      <th>State</th>
      <th>Preview</th>
    </tr>
  );
};

export default TeamTableHeader;
