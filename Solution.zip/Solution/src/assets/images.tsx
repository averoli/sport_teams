import almeria from "./images/almeria.png";
import real_madrid from "./images/real-madrid.png";
import barcelona from "./images/barcelona.png";
export { almeria, barcelona, real_madrid };
